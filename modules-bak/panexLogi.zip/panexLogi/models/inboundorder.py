from odoo import api, fields, models, _
from odoo.exceptions import UserError


# 入库指令
class InboundOrder(models.Model):
    _name = 'panexlogi.inbound.order'
    _description = 'panexlogi.inbound.order'
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _rec_name = 'billno'

    billno = fields.Char(string='BillNo', readonly=True)
    date = fields.Date(string='Date（单据日期）', required=True, tracking=True, default=fields.Date.today)
    project = fields.Many2one('panexlogi.project', string='Project（项目）', required=True)
    waybill_billno = fields.Many2one(comodel_name='panexlogi.waybill', string='Waybill NO')
    waybillno = fields.Char(string='B/L NUMBER', related='waybill_billno.waybillno', readonly=True, store=True)
    remark = fields.Text(string='Remark')
    color = fields.Integer()
    state = fields.Selection(
        selection=[
            ('new', 'New'),
            ('confirm', 'Confirm'),
            ('cancel', 'Cancel'),
        ],
        default='new',
        string="State",
        tracking=True
    )
    inbound_order_product_ids = fields.One2many('panexlogi.inbound.order.products', 'inboundorderid')

    @api.model
    def create(self, values):
        """
        生成跟踪单号
        """
        times = fields.Date.today()
        values['billno'] = self.env['ir.sequence'].next_by_code('seq.inbound.order', times)
        values['state'] = 'new'
        return super(InboundOrder, self).create(values)
    """
    @api.onchange('waybill_billno')
    def _get_blno(self):
        for r in self:
            # r.waybillno = None
            if r.waybill_billno:
                r.waybillno = r.waybill_billno.waybillno
    """