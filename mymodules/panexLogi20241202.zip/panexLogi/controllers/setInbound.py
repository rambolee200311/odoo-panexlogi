from odoo import http, fields
from odoo.http import request


# 逐行更新入库订单明细
class setInboundProduct(http.Controller):
    @http.route('/setInboundProduct', type='json', auth="user", cors="*", csrf=False)
    def setInboundProduct(self, **kw):
        did = kw.get('did')

        inbound_order_products = request.env['panexlogi.inbound.order.products'].sudo().search([('id', '=', did)])
        if not inbound_order_products:
            back_data = {'code': 300, 'msg': 'inbound order products不存在'}
            return (back_data)
        else:
            request.env['panexlogi.inbound.order.products.scan'].sudo().create({
                'inbound_order_products_id': did,
                'warehouse_id': kw.get('warehouse_id'),
                'location_id': kw.get('location_id'),
                'pda_id': kw.get('pda_id'),
                'product_id': kw.get('product_id'),
                'batch': kw.get('batch'),
                'pcs': kw.get('pcs'),
                'pallets': kw.get('pallets'),
                'cntrno': kw.get('cntrno'),
                'palletdno': kw.get('palletdno'),
                'sncode': kw.get('sncode')
            })  # 新增inbound order products scan

            inbound_order_products.write({
                'state': 'in-Operation',
                'total_pallets': inbound_order_products.total_pallets + kw.get('pallets'),
                'total_pcs': inbound_order_products.total_pcs + kw.get('pcs'),
            })  # 更新inbound order products

            back_data = {'code': 100, 'msg': '更新inbound order products成功'}
            return (back_data)


# 获取入库订单操作明细
class getInboundProduct(http.Controller):
    @http.route('/getInboundProduct', type='json', auth="user", cors="*", csrf=False)
    def getInboundProduct(self, **kw):
        domain = []
        # domain.append('&')
        # domain.append((1, '=', 1))
        # order id
        id = kw.get('id')
        if id:
            inboundorders = request.env['panexlogi.inbound.order.products'].sudo().search([('inboundorderid', '=', id)])
            if inboundorders:
                # domain.append('&')
                j = len(inboundorders)
                if j > 1:
                    for i in range(1, j):
                        domain.append('|')
                # domain.append((1, '=', 0))
                for r in inboundorders:
                    domain.append(('inbound_order_products_id', '=', r.id))

        # order products id
        did = kw.get('did')
        if did:
            # domain.append('&')
            # domain.append((1, '=', 1))
            domain.append(('inbound_order_products_id', '=', did))
        # order products product_id
        product_id = kw.get('product_id')
        if product_id:
            domain.append(('product_id', '=', product_id))
        # order products pda_id
        pda_id = kw.get('pda_id')
        if pda_id:
            domain.append(('pda_id', '=', pda_id))
        # order products cntrno
        cntrno = kw.get('cntrno')
        if cntrno:
            domain.append(('cntrno', '=', cntrno))
        palletdno = kw.get('palletdno')
        if palletdno:
            domain.append(('palletdno', '=', palletdno))
        batch = kw.get('batch')
        if batch:
            domain.append(('batch', '=', batch))

        inbound_order_products_scan = request.env['panexlogi.inbound.order.products.scan'].sudo().search(domain)
        if not inbound_order_products_scan:
            back_data = {'code': 300, 'msg': 'inbound order product scan 不存在'}
            return (back_data)

        listIds = []
        for r in inbound_order_products_scan:
            singID = {
                "did": r.id,
                "inbound_order_products_id": r.inbound_order_products_id.id,
                "warehouse_id": r.warehouse_id.id,
                "location_id": r.location_id.id,
                "pda_id": r.pda_id,
                "product_id": r.product_id.id,
                "product_name": r.product_id.name,
                "product_barcode": r.product_id.barcode,
                "batch": r.batch,
                "cntrno": r.cntrno,
                "pcs": r.pcs,
                "pallets": r.pallets,
                "palletdno": r.palletdno,
                "sncode": r.sncode,
            }
            listIds.append(singID)
        data = {"productscan": listIds}
        back_data = {'code': 100, 'msg': '查询inbound order product scan成功', 'data': data}
        return back_data


# 新增入库操作
class setInboundOperate(http.Controller):
    @http.route('/setInboundOperate', type='json', auth="user", cors="*", csrf=False)
    def setInboundOperate(self, **kw):
        inbound = kw.get('inbound')
        products = inbound["inbound_products"]  # kw.get('inbound_products')
        # print("inbound==", inbound)
        # print("products==", products)
        # stockPicks=open("stockPicks.json", "r")
        # listStockPicks=json.load(stockPicks)
        listIds = []
        for r in products:
            singID = (0, 0, {
                "product_id": r["product_id"],
                "pcs": r["pcs"]}
                      )
            listIds.append(singID)
        data = {
            "date": inbound["date"],
            "order_billno": request.env['panexlogi.inbound.order'].sudo().search(
                [('billno', '=', inbound["order_billno"])]).id,
            "remark": inbound["remark"],
            "inbound_operate_product_ids": listIds
        }
        print("data==", data)
        id = request.env['panexlogi.inbound.operate'].sudo().create(data)
        back_data = {'code': 100, 'msg': '新增inbound成功', 'data': id.billno}
        return (back_data)
